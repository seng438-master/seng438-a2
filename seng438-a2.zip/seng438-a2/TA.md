**SENG 438 - Software Testing, Reliability, and Quality**


> Instructor: Dr. Behrouz Far (far@ucalgary.ca)

> Teaching Assistants:

> - Yousef Mehrdad Bibalan (yousef.mehrdadbibala@ucalgary.ca)
> - Masoud Karimi Fatemi (masoud.karimifatemi@ucalgary.ca)
> - Anja Slama (anja.slama@ucalgary.ca)
