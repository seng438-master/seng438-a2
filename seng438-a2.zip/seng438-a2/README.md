# seng438-assignment-2

# Guidline

- read [assignment guideline](./Assignment2.md)
- commit and push output ([assignment output template](./Assignment2-ReportTemplate.md))
